﻿using System;

namespace TabuadaDoDois
{
    internal class Program
    {
        static void Main(string[] args)
        {
            for (int i = 1; i <= 10; i++)
            {
                Console.WriteLine(i + " x 2 = " + i * 2);
            }
            Console.ReadLine();
        }
    }
}